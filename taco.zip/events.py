import pygame
gameover = pygame.event.custom_type()
dropburrito = pygame.event.custom_type()