from enum import Enum

class States(Enum):
    TITLE = ('Raining Tacos')
    GAMEOVER = ('Game Over!')
    ACTUALGAME = ('Gaem')